# Validação

## V44.4 — domínio próprio da API

A API pública de produção é:

`https://api.kamylisumire.com`

Durante a estabilização, `workers.dev` permanece como fallback.

Validação manual obrigatória:

1. abrir `https://api.kamylisumire.com/`;
2. confirmar resposta JSON do ranking;
3. confirmar CORS para `https://kamylisumire.com`;
4. confirmar que Streamlabs e Cloudflare usam
   `https://api.kamylisumire.com/oauth/callback`;
5. reautorizar o OAuth no domínio novo;
6. abrir `/doacoes/` e confirmar no console:
   `API atendida por: https://api.kamylisumire.com`;
7. confirmar ranking e fallback/cache.

## CI automática

Execute:

```bash
python .github/scripts/validate-content.py
find js -type f -name '*.js' -print0 | xargs -0 -n1 node --check
git diff --check
```

O validador estrutural anterior pode emitir um aviso ao detectar
`useCustomDomain: true`. Esse aviso é esperado nesta migração e não é erro.

## Limites da validação estática

A CI não prova disponibilidade do Cloudflare Worker, Streamlabs ou KV.
A migração do domínio exige smoke test real em navegador.

A Home deve continuar funcionando mesmo que todos os endpoints do ranking
estejam indisponíveis.

## V45.2 — blur pós-loader

Contrato:

1. `body > main` não fica `opacity: 0` durante o loader;
2. `.site-loader` não usa `backdrop-filter` fullscreen;
3. o loader opaco cobre conteúdo que continua paintable atrás dele;
4. o fundo AVIF apropriado é preloaded somente com blur ligado/performance normal;
5. `loader.js` tenta decodificar esse fundo antes do reveal, com timeout;
6. `.glass-panel`, `.site-nav` e `.site-footer` são aquecidos antes do reveal;
7. blur off/Save-Data/performance reduzida não antecipam o fundo.

A CI contém guardas para os principais itens acima.


## V45.2.1 — loader com blur

O loader volta a usar a superfície translúcida do site:

- `background-color: var(--card-bg)`;
- `backdrop-filter: blur(var(--blur-card))`;
- tema claro/escuro continua vindo dos tokens globais;
- `data-blur="off"` remove o filtro do loader;
- a página continua renderizável atrás do loader.

Limitação conhecida e aceita: em alguns navegadores/dispositivos pode existir
um curto intervalo até a composição final do blur dos painéis depois do
reveal. A V45.2.1 não tenta eliminar completamente esse comportamento.

## V45.2.2 — loader separado da página

Sequência:

1. loader translúcido permanece visível;
2. Navbar, `main` e Footer permanecem invisíveis;
3. loader faz fade-out por 320 ms;
4. o loader é removido;
5. há um intervalo adicional de 150 ms;
6. só então `site-revealing` inicia a entrada da página.

A página não deve aparecer por trás do loader.

A pequena diferença de composição do blur dos cards após o reveal permanece
como limitação conhecida e aceita.
